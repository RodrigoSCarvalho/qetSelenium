package exselenium;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TesteConta {

    protected WebDriver driver;
    protected WebElement element;

    @BeforeClass
    public static void configuraDriver() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Aluno.L306-8B.029\\Documents\\chrome\\chromedriver.exe");
    }

    @Before
    public void createDriver() {

        driver = new ChromeDriver();
        driver.get("https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp");
    }

    @Test
    public void test() {
        element = driver.findElement(By.xpath("//*[@id=\"firstName\"]"));
        element.sendKeys("Rodrigo");
        element = driver.findElement(By.xpath("//*[@id=\"lastName\"]"));
        element.sendKeys("Carvalho");
        element = driver.findElement(By.xpath("//*[@id=\"username\"]"));
        element.sendKeys("rodrigo");
        element = driver.findElement(By.xpath("//*[@id=\"passwd\"]/div[1]/div/div[1]/input"));
        element.sendKeys("rodrigo");
        element = driver.findElement(By.xpath("//*[@id=\"confirm-passwd\"]/div[1]/div/div[1]/input"));
        element.sendKeys("rodrigo");
        element = driver.findElement(By.xpath("//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[2]/div[1]/div/div[2]/div[2]/div"));
        Assertions.assertTrue(element.getText().contains("Este nome de usuário não é permitido. Tente novamente."));
    }
/*
    @After
    public void quitDriver() {
        driver.quit();
    }
    */
}
