package exselenium;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertTrue;


public class TestaGoogle {

    protected WebDriver driver;
    protected WebElement element;

    @BeforeClass
    public static void configuraDriver() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Aluno.L306-8B.029\\Documents\\chrome\\chromedriver.exe");
    }

    @Before
    public void createDriver() {

        driver = new ChromeDriver();
        driver.get("https://www.google.com.br");
    }

    @Test
    public void test() {
        element = driver.findElement(By.name("q"));
        element.sendKeys("Olá");
        element.submit();
        assertTrue(driver.getTitle().contains("Teste - Pesquisa"));

    }
/*
    @After
    public void quitDriver() {
        driver.quit();
    }
    */
}